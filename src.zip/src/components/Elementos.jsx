import React, { Component } from 'react'

export default class Elementos extends Component {
    constructor(props){
        super(props);
        this.state={
            name:"",
            img:"#",
           
            
        }
    }

     async componentDidMount(){
        await this.fetchApi();
     }

     fetchApi = async()=> {
        let resp= await fetch(`https://pokeapi.co/api/v2/pokemon/${this.state.name}`);
        let data = await resp.json();
        console.log(data.sprites.front_default);

 this.setState({
    img: data.sprites.front_default
})
     }
     handlerName = event =>{
        this.setState({
            name: event.target.value
        })
    }
    
    handlerSubmit= event=>{
        let aux = this.state.name
        console.log(aux);
        event.preventDefault();
        this.fetchApi();
    }

  render() {
    return (
        <div>
        <div className="card mt-4">
  <div className="card-header text-black">
    Busca tu Pokemon
  </div>
  <div className="card-body">
    <form onSubmit={this.handlerSubmit}>
        <input 
        type="text"
        placeholder='Search Pokemon Name'
        value= {this.state.name}
        onChange={this.handlerName}
        ></input> 
        <button type="submit" className="btn btn-primary mt-2"> Enviar </button>
       
    </form>
    
  </div>
</div>
<img src={this.state.img}></img>
        </div>
    )
  }
}
