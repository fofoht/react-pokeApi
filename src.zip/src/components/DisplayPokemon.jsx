import React from 'react'
import PokeCard from "./PokeCard"

export default function DisplayPokemon({pokemon}) {
  return (
    <div>
        {
        pokemon.map((value , index)=> 
            <PokeCard key={index} {...value}/>
        )
        }

    </div>
  )
}
