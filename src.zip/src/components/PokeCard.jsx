import axios from 'axios'

import {useState, useEffect} from "react"

export default function PokeCard(props) {

    const[onePokemon,  setOnePokemon]= useState({
        name:" ",
        sprites:{front_default:""}

    })

    const getPokemon = (url) =>{

        axios.get(url)
        .then((response) =>{
            console.log(response.data)
            setOnePokemon(response.data)

        })
    } 
    useEffect(() => {
        getPokemon(props.url)
    },[])

  return (
    <div>
        <div className="card mt-4">
  <div className="card-header text-black">
    {onePokemon.name}
  </div>
  <div className="card-body">
    <img src={onePokemon.sprites.front_default} alt=""/>
    <p className="card-text text-black">weight:{onePokemon.weight}</p>
    
  </div>
</div>
    </div>
  )
}
