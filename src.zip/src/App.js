import logo from './logo.svg';
import './App.css';
import PokeList from './components/PokeList';
import Elementos from './components/Elementos';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h1>Pokedex</h1>
        <Elementos/>
        <PokeList />
      </header>
      
    </div>
  );
}

export default App;
